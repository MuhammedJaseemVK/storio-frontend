import React from 'react'

export default function Subtext(props) {
  return (
    <div>
        <p className='text-[#FFFFFA] text-base font-[Poppins] px-3'>{props.text}</p>
    </div>
  )
}
